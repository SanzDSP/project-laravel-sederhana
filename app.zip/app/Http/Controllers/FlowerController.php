<?php

namespace App\Http\Controllers;

use App\Models\Flower;
use Illuminate\View\View;
use Illuminate\Http\Request;

class FlowerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function productcards() : View
    {
        $flowers = Flower::get();

        return view('product-cards', compact('flowers'));
    }

    public function productdashboard() : View
    {
        $flowers = Flower::get();

        return view('dashboardadmin', compact('flowers'));
    }

    public function createflower() :View
    {
        return view('create-flower');
        //
    }


    /**
     * Store a newly created resource in storage.
     */
    // public function storeflower(Request $request)
    // {
    //     $this->validate($request, [
    //         'namaflower' => 'required',
    //         'hargaflower' => 'required',
    //         'deskripsiflower' => 'required',
    //         'statusflower' => 'required',
    //         'fotoflower' => 'required'
    //     ]);
    //     $data = Flower::create([
    //         'namaflower' => $request->namaflower,
    //         'hargaflower' => $request->hargaflower,
    //         'deskripsiflower' => $request->deskripsiflower,
    //         'statusflower' => $request->statusflower,
    //         'fotoflower' => $request->fotoflower,
    //     ]);
    //     if($request->hasFile('fotoflower')){
    //         $request->file('fotoflower')->move('productcard/images/', $request->file('fotoflower')->getClientOriginalName());
    //         $data->fotoflower = $request->file('fotoflower')->getClientOriginalName();
    //         $data->save();
    //     }
    //     return redirect()->route('dashboard2')->with(['success' => 'Data Berhasil Disimpan!']);
    //     //
    // }
    public function storeflower(Request $request)
{
    $this->validate($request, [
        'namaflower' => 'required',
        'hargaflower' => 'required',
        'deskripsiflower' => 'required',
        'statusflower' => 'required',
        'fotoflower' => 'required', // tambahkan aturan validasi untuk file gambar
    ]);

    $data =Flower::create([
        'namaflower' => $request->namaflower,
        'hargaflower' => $request->hargaflower,
        'deskripsiflower' => $request->deskripsiflower,
        'statusflower' => $request->statusflower,
        'fotoflower' => $request->fotoflower,
    ]);

    // Memeriksa apakah ada file yang diunggah
    if ($request->hasFile('fotoflower')) {
        $request->file('fotoflower')->move('productcard/images/', $request->file('fotoflower')->getClientOriginalName());
        $data->fotoflower = $request->file('fotoflower')->getClientOriginalName();
    }

    $data->save();

    return redirect()->route('admin.dashboard2')->with(['success' => 'Data Berhasil Disimpan!']);
}


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function editflower(string $id) : View
    {
        //get bukuu by ID
        $flower = Flower::findOrFail($id);

        //render view with bukuu
        return view('edit-flower', compact('flower'));
        //
    }

    /**
     * Update the specified resource in storage.
     */
    // public function updateflower(Request $request, string $id)
    // {
    //     $this->validate($request, [
    //         'namaflower' => 'required',
    //         'hargaflower' => 'required',
    //         'deskripsiflower' => 'required',
    //         'statusflower' => 'required',
    //         'fotoflower' => 'required'
    //     ]);

    //     $flower = Flower::findOrFail($id);
    //     $flower->update([
    //         'namaflower' => $request->namaflower,
    //         'hargaflower' => $request->hargaflower,
    //         'deskripsiflower' => $request->deskripsiflower,
    //         'statusflower' => $request->statusflower,
    //         'fotoflower' => $request->fotoflower,
    //     ]);
    //     if($request->hasFile('fotoflower')){
    //         $request->file('fotoflower')->move('productcard/images/', $request->file('fotoflower')->getClientOriginalName());
    //         $flower->fotoflower = $request->file('fotoflower')->getClientOriginalName();
    //         $flower->save();
    //     }
    //     return redirect()->route('dashboard2')->with(['success' => 'Data Berhasil Diubah!']);
    //     //
    // }
    public function updateflower(Request $request, string $id)
{
    $this->validate($request, [
        'namaflower' => 'required',
        'hargaflower' => 'required',
        'deskripsiflower' => 'required',
        'statusflower' => 'required',
    ]);

    $flower = Flower::findOrFail($id);

    // Memperbarui data tanpa memperbarui foto jika tidak ada file yang diunggah
    $flower->update([
        'namaflower' => $request->namaflower,
        'hargaflower' => $request->hargaflower,
        'deskripsiflower' => $request->deskripsiflower,
        'statusflower' => $request->statusflower,
    ]);

    // Memeriksa apakah ada file yang diunggah
    if ($request->hasFile('fotoflower')) {
        // Menghapus foto lama jika ada
        if (file_exists(public_path('productcard/images/' . $flower->fotoflower))) {
            unlink(public_path('productcard/images/' . $flower->fotoflower));
        }

        // Menyimpan foto baru
        $request->file('fotoflower')->move('productcard/images/', $request->file('fotoflower')->getClientOriginalName());
        $flower->fotoflower = $request->file('fotoflower')->getClientOriginalName();
        $flower->save();
    }

    return redirect()->route('admin.dashboard2')->with('success', 'Data Berhasil Diubah!');
}


    /**
     * Remove the specified resource from storage.
     */
    public function destroyflower(string $id)
    {
        $flower = Flower::findOrFail($id);
        $flower->delete();
        return redirect()->route('admin.dashboard2')->with(['success' => 'Data Berhasil Dihapus!']);
        //
    }
}
