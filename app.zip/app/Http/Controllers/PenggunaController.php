<?php

namespace App\Http\Controllers;

use App\Models\Pengguna;
use App\Models\User;
//use App\Http\Controllers\Hash;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class PenggunaController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function index(){
        return view('logreg');
    }

    public function loginuser(Request $request)
    {
        $request->validate([
            'username'  => 'required',
            'password'  => 'required',
        ]);

        $data = [
            'name'  => $request->username,
            'password'  => $request->password,
        ];

        if(Auth::attempt($data)){
            return redirect()->route('admin.dashboard2')->with('succes','Selamat Datang!');
        } else {
            return redirect()->route('login')->with('failed','username atau Password salah!');
        }
    }

    // Proses logout
    public function logoutuser(Request $request)
    {
        Auth::logout();
        return redirect()->route('login')->with('succes','Anda telah logout');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function createuser()
    {
        return view('logreg');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function storeuser(Request $request)
    {
        $request->validate([
            'username'  => 'required',
            'email'     => 'required|email|unique:users,email',
            'password'  => 'required|min:6',
        ]);

        $data['name']       = $request->username;
        $data['email']      = $request->email;
        $data['password']   = Hash::make($request->password);

        User::create($data);

        // $data =User::create([
        //     'name' => $request->username,
        //     'email' => $request->email,
        //     'password' => Hash::make($request->password),
        // ]);
        // $data->save();
        return redirect()->route('login')->with('succes','Akun anda telah terdaftar!');

        // versi regeister langsung dasshboard
        // $login = [
        //     'name'  => $request->username,
        //     'password'  => $request->password,
        // ];

        // if(Auth::attempt($login)){
        //     return redirect()->route('dashboard2')->with('succes','Selamat Datang!');
        // } else {
        //     return redirect()->route('login')->with('failed','Email atau Password salah!');
        // }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
