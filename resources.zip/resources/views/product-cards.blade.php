<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="productcard/css/style.css">

   <!-- custom js file link  -->
   <script src="productcard/js/script.js" defer></script>

   <link rel="shortcut icon" href="favicon.png">
   <title>Flower Stores</title>
</head>
<body style="background-image: url('productcard/backgroundproduct.jpg')">


<!-- <div class="container">
    <h3 class="title"> Flower products </h3>

    <div class="products-container">
        @foreach ($flowers as $flower)
            <div class="product" data-id="{{ $flower->id }}">
                <img src="{{ 'productcard/images/'.$flower->fotoflower }}" alt="">
                <h3>{{ $flower->namaflower }}</h3>
                <div class="price">{{ $flower->hargaflower }}</div>
            </div>
        @endforeach
    </div>
</div>

<div class="products-preview">
    <div class="preview" id="previewTemplate">
        <i class="fas fa-times close-preview"></i>
        <img src="" alt="">
        <h3></h3>
        <div class="stars">
        <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>({!! $flower->statusflower !!})</span>
        </div>
        <p>{{ $flower->deskripsiflower }}</p>
      <div class="price">{{ $flower->hargaflower }}</div>
      <div class="buttons">
         <a href="#" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div>
   </div>

   </div> -->


<div class="container" >

   <h3 class="title"> Flower products </h3>

   <div class="products-container" >

        @foreach ($flowers as $flower)
        <div class="product" data-name="{{ $flower->id }}">
         <img src="{{ ('productcard/images/'.$flower->fotoflower) }}" alt="">
         <h3>{{ $flower->namaflower }}</h3>
         <div class="price">{{ $flower->hargaflower }}</div>
      </div>
      @endforeach
   </div>

</div>

<div class="products-preview">
   @foreach ($flowers as $flower)
   <div class="preview" data-target="{{ $flower->id }}">
      <i class="fas fa-times"></i>
      <img src="{{ ('productcard/images/'.$flower->fotoflower) }}" alt="">
      <h3>{{ $flower->namaflower }} Flower</h3>
      <div class="stars">
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star"></i>
         <i class="fas fa-star-half-alt"></i>
         <span>({!! $flower->statusflower !!})</span>
      </div>
      <p>{{ $flower->deskripsiflower }}</p>
      <div class="price">{{ $flower->hargaflower }}</div>
      <!-- <div class="buttons">
         <a href="#" class="buy">buy now</a>
         <a href="#" class="cart">add to cart</a>
      </div> -->
   </div>
   @endforeach

   </div>



</body>
</html>