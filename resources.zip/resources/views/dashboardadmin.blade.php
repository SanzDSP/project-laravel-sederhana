<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="dashboardadmin/adminstyle.css"> -->
    <link rel="stylesheet" href="{{ asset('dashboardadmin/adminstyle.css') }}">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- <link rel="shortcut icon" href="favicon.png"> -->
    <link rel="shortcut icon" href="{{ asset('favicon.png') }}">
    <title>Admin</title>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <ul>
                <li>
                    <a href="#">
                        <!-- <i class="fas fa-crown"></i> -->
                        <img src="{{ asset('dashboardadmin/starkindustries22.png') }}" alt="" style="height:150px;width:300px;margin-left:-40px;">
                        <!-- <i class="fas fa-clinic-medical"></i> -->
                        <div class="title"></div>
                        <!-- <div class="title">Umbrella</div> -->
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-th-large"></i>
                        <div class="title">Dashboard</div>
                    </a>
                </li>
                <!-- <li>
                    <a href="#">
                        <i class="fas fa-stethoscope"></i>
                        <div class="title">Appointments</div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-user-md"></i>
                        <div class="title">Doctors</div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-puzzle-piece"></i>
                        <div class="title">Departments</div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-hand-holding-usd"></i>
                        <div class="title">Payments</div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-cog"></i>
                        <div class="title">Settings</div>
                    </a>
                </li> -->
                <!-- <li>
                    <a href="#">
                        <i class="fas fa-question"></i>
                        <div class="title">Help</div>
                    </a>
                </li> -->
                <li>
                    <a href="#">
                        <!-- <i class="fas fa-question"></i> -->
                        <i class="fas fa-inbox-out"></i>
                        <form method="GET" action="{{ route('logout') }}">
                            @csrf <!-- Token CSRF untuk keamanan -->
                            <button class="title" type="submit" style="background-color:transparent;border:none;color:white;">Logout</button>
                        </form>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main">
            <div class="top-bar">
                <div class="search">
                    <input type="text" name="search" placeholder="search here">
                    <label for="search"><i class="fas fa-search"></i></label>
                </div>
                <i class="fas fa-bell"></i>
                <div class="user">
                    <img class="gambarProfile" src="{{ asset('/dashboardadmin/elaina1.jpg')}}" alt="" style="border-radius:10px">
                </div>
            </div>
            <div class="cards">
                <div class="card">
                    <div class="card-content">
                        <div class="number">67</div>
                        <div class="card-name">Maintenance</div>
                    </div>
                    <div class="icon-box">
                        <i class="fas fa-briefcase-medical"></i>
                    </div>
                </div>
                <div class="card">
                    <div class="card-content">
                        <div class="number">915</div>
                        <div class="card-name">Our Collection</div>
                    </div>
                    <div class="icon-box">
                        <i class="fas fa-flower-tulip"></i>
                    </div>
                </div>
                <div class="card">
                    <div class="card-content">
                        <div class="number">138</div>
                        <div class="card-name">Employees</div>
                    </div>
                    <div class="icon-box">
                        <i class="fas fa-handshake-alt"></i>
                    </div>
                </div>
                <div class="card">
                    <div class="card-content">
                        <div class="number">$4500</div>
                        <div class="card-name">Daily income</div>
                    </div>
                    <div class="icon-box">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                </div>
            </div>
            <div class="tables">
                <div class="last-appointments">
                    <div class="heading">
                        <h2>Products Data</h2>
                        <a href=" {{ route('admin.flowers.createflower') }}" class="btn">Create a Product</a>
                    </div>
                    <table class="appointments">
                    <thead>
                        <tr>
                                    <td scope="col">Name</td>
                                    <td class="text-center" scope="col">Foto</td>
                                    <td scope="col">Description</td>
                                    <td scope="col">Price</td>
                                    <td scope="col">Status</td>
                                    <td class="text-center" scope="col">Actions</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($flowers as $flower)
                                    
                                    <td>{{ $flower->namaflower }}</td>
                                    <td>
                                        <center>
                                        <img src="{{ asset('productcard/images/'.$flower->fotoflower) }}" alt="" style="width: 40px;height=40px;">
                                        </center>
                                    </td>
                                    <td>{!! $flower->deskripsiflower !!}</td>
                                    <td>{{ $flower->hargaflower }}</td>
                                    <td>{!! $flower->statusflower !!}</td>
                                    <td class="text-center">
                                    <form onsubmit="return confirm('Apakah Anda Yakin Ingin Menghapus {{ $flower->namaflower }} ?');" action="{{ route('admin.flowers.destroyflower', $flower->id) }}" method="POST">
                                        <a href=" {{ route('admin.flowers.editflower', $flower->id) }}" class="btn btn-sm btn-primary" style="background-color: orange; border:none">EDIT</a>
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                    </form>
                                    </td>
                                    </tr>
                                    @empty
                                    <div class="alert alert-danger">
                                        Data Post belum Tersedia.
                                    </div>
                                    @endforelse
                                </tbody>
                        <!-- <thead>
                            <td>Name</td>
                            <td>Doctor</td>
                            <td>Condition</td>
                            <td>Actions</td>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Liam Smith Doe</td>
                                <td>Dr. Benjamin</td>
                                <td>fracture</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Emma</td>
                                <td>Dr. Noah</td>
                                <td>depression</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Olivia Smith </td>
                                <td>Dr. Liam</td>
                                <td>arthritis</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Isabella Doe</td>
                                <td>Dr. Noah</td>
                                <td>flu</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Sophia Smith </td>
                                <td>Dr. Olivia</td>
                                <td>fracture</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                            <tr>
                                <td>Liam Smith Doe</td>
                                <td>Dr. Benjamin</td>
                                <td>fracture</td>
                                <td>
                                    <i class="far fa-eye"></i>
                                    <i class="far fa-edit"></i>
                                    <i class="far fa-trash-alt"></i>
                                </td>
                            </tr>
                        </tbody> -->
                    </table>
                </div>
                <!-- <div class="doctor-visiting">
                    <div class="heading">
                        <h2>Doctor Visiting</h2>
                        <a href="#" class="btn">create</a>
                    </div>
                    <table class="visiting">
                        <thead>
                            <td>Photo</td>
                            <td>Name</td>
                            <td>Visit time</td>
                            <td>Detail</td>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="img-box-small">
                                        <img src="doctor1.png" alt="">
                                    </div>
                                </td>
                                <td>Benjamin</td>
                                <td>14:00</td>
                                <td><i class="far fa-eye"></i></td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="img-box-small">
                                        <img src="doctor3.jpg" alt="">
                                    </div>
                                </td>
                                <td>Liam</td>
                                <td>15:00</td>
                                <td><i class="far fa-eye"></i></td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="img-box-small">
                                        <img src="doctor2.png" alt="">
                                    </div>
                                </td>
                                <td>Noah</td>
                                <td>16:00</td>
                                <td><i class="far fa-eye"></i></td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="img-box-small">
                                        <img src="doctor4.png" alt="">
                                    </div>
                                </td>
                                <td>Sophia</td>
                                <td>17:00</td>
                                <td><i class="far fa-eye"></i></td>
                            </tr>
                        </tbody>
                    </table>
                </div> -->
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    @if($message = Session::get('failed'))
    <script>
        Swal.fire({
            title: "Failed!",
            text: '{{ $message }}',
            icon: "error"
        });
    </script>
    @endif

    @if($message = Session::get('succes'))
    <script>
        Swal.fire({
            title: "Succes!",
            text: '{{ $message }}',
            icon: "success"
        });
    </script>
    @endif
</body>
</html>