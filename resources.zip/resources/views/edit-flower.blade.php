<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Data</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="shortcut icon" href="favicon.png"> -->
    <link rel="shortcut icon" href="{{ asset('favicon.png') }}">
</head>
<body style="background-image: url({{ asset('background/backgroundDaun3.jpg') }}); background-size: cover; background-repeat: no-repeat;">
<!-- <body style="background-image: url('/background/backgroundDaun3.jpg'); background-size: cover; background-repeat: no-repeat;"> -->
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body" style="background-image: url({{ asset('background/backgroundDaun3.jpg') }}); background-size: cover; background-repeat: no-repeat; border-radius: 10px;">
                    <!-- <div class="card-body" style="background-image: url('/background/backgroundDaun3.jpg'); background-size: cover; background-repeat: no-repeat; border-radius: 10px;"> -->
                        <form action="{{ route('admin.flowers.updateflower', $flower->id) }}" method="POST" enctype="multipart/form-data">
                        <h3 class="text-center my-4" style="color: white; font-family: 'EB Garamond', serif;" >Tambah Data</h3>
                            @csrf
                            <div class="form-group">
                                <label class="font-weightbold" style="color:white">Name</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" name="namaflower" value="{{ old('namaflower',$flower->namaflower) }}" placeholder="Name Flower">
                                <!-- error message untuk title -->
                                @error('title')
                                <div class="alert alert-danger mt-2">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label class="font-weightbold" style="color:white">Price</label>
                                <input type="text" class="form-control @error('price') is-invalid @enderror" name="hargaflower" value="{{ old('hargaflower',$flower->hargaflower) }}" placeholder="Harga Flower">
                                <!-- error message untuk title -->
                                @error('harga')
                                <div class="alert alert-danger mt-2">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label class="font-weightbold" style="color:white">Description</label>
                                <input type="text" class="form-control @error('description') is-invalid @enderror" name="deskripsiflower" value="{{ old('deskripsiflower',$flower->deskripsiflower) }}" placeholder="Deskripsi Flower">
                                <!-- error message untuk title -->
                                @error('description')
                                <div class="alert alert-danger mt-2">
                                    {{ $message }}
                                </div>
                                    @enderror
                            </div>
                            <div class="form-group">
                                <label class="font-weightbold" style="color:white">Status</label>
                                <input type="text" class="form-control @error('status') is-invalid @enderror" name="statusflower" value="{{ old('statusflower',$flower->statusflower) }}" placeholder="Status Flower">
                                <!-- error message untuk title -->
                                @error('status')
                                <div class="alert alert-danger mt-2">
                                    {{ $message }}
                                </div>
                                    @enderror
                            </div>
                            <div class="form-group">
                                <label class="font-weightbold" style="color:white">Input Photo</label>
                                <input type="file" class="form-control @error('photo') is-invalid @enderror" name="fotoflower" value="{{ old('fotoflower',$flower->fotoflower) }}" placeholder="foto flower">
                                <!-- error message untuk title -->
                                @error('photo')
                                <div class="alert alert-danger mt-2">
                                    {{ $message }}
                                </div>
                                    @enderror
                            </div>
                            <button type="submit" class="btn btn-md btnprimary" style="color:white; background-color: green; border:none">SAVE</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    @if($message = Session::get('failed'))
    <script>
        Swal.fire({
            title: "Failed!",
            text: '{{ $message }}',
            icon: "error"
        });
    </script>
    @endif

    @if($message = Session::get('succes'))
    <script>
        Swal.fire({
            title: "Succes!",
            text: '{{ $message }}',
            icon: "success"
        });
    </script>
    @endif
    </body>
</html>
