<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Insert Data</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- <link rel="shortcut icon" href="favicon.png"> -->
        <link rel="shortcut icon" href="{{ asset('favicon.png') }}">
    </head>
    <body style="background-image: url({{ asset('background/backgroundDaun.jpg') }}); background-size: cover; background-repeat: no-repeat;">
    <!-- <body style="background-image: url('background/backgroundDaun.jpg'); background-size: cover; background-repeat: no-repeat;"> -->
        <div class="container mt-5 mb-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card border-0 shadow-sm rounded">
                        <div class="card-body" style="background-image: url({{ asset('background/backgroundDaun.jpg') }}); background-size: cover; background-repeat: no-repeat; border-radius: 10px;">
                        <!-- <div class="card-body" style="background-image: url('background/backgroundDaun.jpg'); background-size: cover; background-repeat: no-repeat; border-radius: 10px;"> -->
                            <form action="{{ route('admin.flowers.storeflower') }}" method="POST" enctype="multipart/form-data">
                            <h3 class="text-center my-4" style="color: white; font-family: 'EB Garamond', serif;" >Create a Data</h3>
                                @csrf
                                <div class="form-group">
                                    <label class="font-weightbold" style="color:white">Name</label>
                                    <input type="text" class="form-control @error('Name') is-invalid @enderror" name="namaflower" value="{{ old('namaflower') }}" placeholder="Name Flower">
                                    <!-- error message untuk title -->
                                    @error('name')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label class="font-weightbold" style="color:white">Price</label>
                                    <input type="text" class="form-control @error('Price') is-invalid @enderror" name="hargaflower" value="{{ old('hargaflower') }}" placeholder="Price Flower">
                                    <!-- error message untuk title -->
                                    @error('harga')
                                    <div class="alert alert-danger mt-2">
                                        <!-- 2x kurung kurawa message -->
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label class="font-weightbold" style="color:white">Description</label>
                                    <input type="text" class="form-control @error('description') is-invalid @enderror" name="deskripsiflower" value="{{ old('deskripsiflower') }}" placeholder="Description Flower">
                                    <!-- error message untuk title -->
                                    @error('deskripsi')
                                    <div class="alert alert-danger mt-2">
                                        <!-- 2x kurung kurawa message -->
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label class="font-weightbold" style="color:white">Status</label>
                                    <input type="text" class="form-control @error('status') is-invalid @enderror" name="statusflower" value="{{ old('statusflower') }}" placeholder="Status Flower">
                                    <!-- error message untuk title -->
                                    @error('status')
                                    <div class="alert alert-danger mt-2">
                                        <!-- 2x kurung kurawa message -->
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label class="font-weightbold" style="color:white">Input Photo</label>
                                    <input type="file" class="form-control @error('foto') is-invalid @enderror" name="fotoflower" value="{{ old('fotoflower') }}" placeholder="Foto Flower">
                                    <!-- error message untuk title -->
                                    @error('foto')
                                    <div class="alert alert-danger mt-2">
                                        <!-- 2x kurung kurawa message -->
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>
                                <button type="submit" class="btn btn-md btnprimary" style="color:white; background-color: green; border:none">ADD</button>
                                <button type="reset" class="btn btn-md btnwarning" style="color:white; background-color: gray; border:none">RESET</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
</html>