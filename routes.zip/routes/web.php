<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FlowerController;
use App\Http\Controllers\PenggunaController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', [PenggunaController::class, 'createuser'])->name('register');
Route::post('/register-proses', [PenggunaController::class, 'storeuser'])->name('signup');

Route::get('/login', [PenggunaController::class, 'index'])->name('login');
Route::post('/login-proses', [PenggunaController::class, 'loginuser'])->name('signin');
Route::get('/logout', [PenggunaController::class, 'logoutuser'])->name('logout');

// Route::get('/dashboardadmin2', function () {
//     return view('dashboardadmin');
// });
Route::get('/products', [FlowerController::class, 'productcards'])->name('product');

Route::group(['prefix' => 'admin','middleware' => ['auth'], 'as' =>'admin.'], function(){

    Route::get('/dashboardadmin2', [FlowerController::class, 'productdashboard'])->name('dashboard2');
    //Route::get('/dashboardadmin', [FlowerController::class, 'dashboardadmin'])->name('flower');
    // Route::get('/products', function () {
    //     return view('product-cards');
    // });
    Route::post('/flower', [flowerController::class, 'storeflower'])->name("flowers.storeflower");
    Route::get('/createflower', [flowerController::class, 'createflower'])->name("flowers.createflower");
    Route::post('/flower/{flower}', [flowerController::class, 'updateflower'])->name("flowers.updateflower");
    Route::delete('/flower/{flower}', [flowerController::class, 'destroyflower'])->name("flowers.destroyflower");
    Route::get('/flower/{flower}/edit', [flowerController::class, 'editflower'])->name("flowers.editflower");
});
