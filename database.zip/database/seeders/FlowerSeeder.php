<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //new part

class FlowerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('flowers')->insert([
            'namaflower' => 'White Lily',
            'hargaflower' => 'Rp. 15.000',
            'deskripsiflower' => 'Bunga yang melambangkan keberuntungan bagi pemiliknya',
            'fotoflower' => '',
        ]);
    }
}
